package edu.umkc.tetrisplugin1;

import java.util.Map;

public interface ITetris {
	
	void buildTetrisApp(int numOfPlayers,  Map<String, Object> tetrisMap);

}
